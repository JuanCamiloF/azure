let model;

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
let isDrawing = false;

//cargar el modelo

async function loadModel() {
  model = await tf.loadLayersModel("./model.json");
  console.log("modelo correctamente cargado");
}

loadModel();

// dibujar en el canvas

function startDrawing() {
  isDrawing = true;
  draw(e);
}
function draw(e) {
  if (!isDrawing) return;

  ctx.lineWidth = 20;
  ctx.lineCap = "round";
  ctx.strokeStyle = "black";

  ctx.lineTo(e.offsetX, e.offsetY);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(e.offsetX, e.offsetY);
}
function endDrawing() {
  isDrawing = false;
  ctx.beginPath();
}

canvas.addEventListener("mousedown", startDrawing);
canvas.addEventListener("mousemove", draw);
canvas.addEventListener("mouseup", endDrawing);

async function predict() {
  let image = tf.browser
    .fromPixels(canvas, 1)
    .resizeNearestNeighbor([28, 28])
    .toFloat()
    .div(255.0)
    .expandDims();

  const prediction = model.predict(image);
  const digit = prediction.argMax(1).dataSync()[0];

  //document.getElementById("resultado").innerHTML = "<p>Prediccion "+digit+"</p>";
  document.getElementById("resultado").innerHTML = `<p>Prediccion ${digit}</p>`;
}

// function clear(){}
document.getElementById("btnClear").addEventListener("click", () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
});

document.getElementById("btnEnviar").addEventListener("click", predict);

// function main() {
//     loadModel();
// }
// main();
