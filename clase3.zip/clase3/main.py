import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import layers, models

# dataset: cantidad de datos en bruto para entrenar el modelo
mnist = tf.keras.datasets.mnist
(x_train, y_train), (x_test,y_test) = mnist.load_data()

# (X_train , y_train) , (X_test , y_test) = keras.datasets.mnist.load_data()

#normalizar imagenes
x_train = x_train/255.0
y_train = y_train/255.0

# crear el modelo
model = tf.keras.Sequential([
    layers.Conv2D(32, (3, 3), activation="relu", input_shape=(28, 28, 1)),  # Capa inicial
    layers.MaxPooling2D((2, 2)),  # Reducción de dimensiones (usar MaxPooling2D en lugar de MaxPooling1D)
    layers.Flatten(),  # Convertir de 2D a 1D
    layers.Dense(128, activation="relu"),  # Capa de análisis
    layers.Dense(10, activation="softmax")  # Capa de salida
])


# model = tf.keras.Sequantial(
#     [
#         layers.Flatten(input_shape=(28,28)),
#         layers.Dense( 128, activation="relu"),
#         layers.Dense(10, activation="softmax")
#     ]
# )


#compilar
model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy", # devolverse a regresion cuadratica
    metrics=["accuracy"]
)

history = model.fit(x_train, y_train, epochs=3, validation_data=(x_test,y_test))

model.save("numbers_handwriting.h5")